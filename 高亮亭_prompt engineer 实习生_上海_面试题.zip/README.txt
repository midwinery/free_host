上班地点在上海市闵行区虹梅南路379弄28号。
请补充以下信息
英语成绩（CET-6/TOEFL/IELTS）：
可实习天数：
最早开始时间：
最晚结束时间：
其他情况：


提交方式：
1. zip 打包，命名方式 `张三_20260131.zip`
2. 发送至 `recruit@gaoliangting.com`，邮件主题: `高亮亭_prompt engineer 实习生面试_张三`