考察要点：
1. 代码健壮性
2. 提示词质量


提交方式：
1. zip 打包，命名方式 `张三_prompt_engineer.zip`, 包括以下材料：
   a. 简历
   c. output.json（包含2页）
   d. answer.py
2. 发送至 `recruit@gaoliangting.com`，邮件主题: `高亮亭_高级prompt engineer面试_张三`