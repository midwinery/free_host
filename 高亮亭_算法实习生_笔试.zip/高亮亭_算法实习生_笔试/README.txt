- 面向人群：上海本地计算机相关专业在校生
- 实习地点：上海市闵行区沪闵路 7399 号啦啦荟城 5 楼创氪际 A05 室（近莲花路地铁站）
- 到岗要求：每周在岗≥4 天
- 实习周期：至少 3 个月


提交方式：
1. zip 打包，命名方式 `张三_20260131.zip`, 包括以下材料：
   a. resume.pdf
   b. info.txt
   c. output.json
   d. langchain.py
2. 发送至 `recruit@gaoliangting.com`，邮件主题: `高亮亭_算法实习生笔试_张三`


info.txt
英语成绩（CET-6/TOEFL/IELTS）：
可实习天数：
最早开始时间：
最晚结束时间：
其他情况：
微信号（若通过面试将通过微信联系）：


langchain.py
1. 提供一个langchain代码，完成 example.json 的任务
2. 显式声明以下变量
```
API_KEY = "key"
BASE_URL = "https://api.blabla.com/v1" 
MODEL = "model"
PAGE = 1
```

output.json
langchain.py 运行结果

